# Waves Learning Notes - LaTeX Source

Version: V4.1
Prepared by: Shang Wu

## Compile

Extract the entire ZIP, preserving its directory structure. Open
`Waves_Complete_Learning_Notes_V4.1_Shang_Wu.tex` in TeXstudio and select
pdfLaTeX, or run the following command from the extracted project folder:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error Waves_Complete_Learning_Notes_V4.1_Shang_Wu.tex
```

The project previously compiled with TeX Live 2026. It uses TikZ/PGFPlots
and standard LaTeX packages. No external textbook PDF or external image
download is needed. The plot data in `expanded/lorentz_index.csv` must
remain at that relative path.

## Included Files

- The V4.1 main document and both required style files.
- All required chapter files, expanded derivations, and diagram definitions.
- The local CSV data used by a figure.

The compiled PDF is provided separately. Previous versions, the practice
set, textbook material, QA files, and compiler-generated files are excluded.

## Licensing

Packaging these files does not select or add an open-content license.
Review third-party rights and choose a suitable license before public release.
